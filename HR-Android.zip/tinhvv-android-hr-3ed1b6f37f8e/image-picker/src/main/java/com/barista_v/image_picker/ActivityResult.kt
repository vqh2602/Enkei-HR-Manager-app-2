package com.barista_v.image_picker

import android.content.Intent

class ActivityResult(val requestCode: Int, val data: Intent?)