//
//  WSLabel.m
//  CalendarDemo
//
//  Created by Dotsquares on 2/15/17.
//  Copyright © 2017 Dotsquares. All rights reserved.
//

#import "WSLabel.h"

@implementation WSLabel

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
