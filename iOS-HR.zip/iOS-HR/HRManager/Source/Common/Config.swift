//
//  Config.swift
//  BaseProject
//
//  Created by Tinh Vu on 7/29/18.
//  Copyright © 2018 alatin studio. All rights reserved.
//

import Foundation
class Config {
//    static var BASE_URL = "http://210.245.26.132:8845/api/" // savis
    static var BASE_URL = "http://103.37.28.141:9700/api/" // enkei
}
