//
//  BaseNavVC.swift
//  BaseProject
//
//  Created by Tinh Vu on 7/29/18.
//  Copyright © 2018 alatin studio. All rights reserved.
//

import UIKit

class BaseNavVC: UINavigationController {
    
}
