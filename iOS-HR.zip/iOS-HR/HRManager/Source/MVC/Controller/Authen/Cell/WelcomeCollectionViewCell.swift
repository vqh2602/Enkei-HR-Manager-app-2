//
//  WelcomeCollectionViewCell.swift
//  HRManager
//
//  Created by Tinh Vu on 1/23/19.
//  Copyright © 2019 Tinh Vu. All rights reserved.
//

import UIKit

class WelcomeCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imv: UIImageView!
    @IBOutlet weak var lbTitle: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

}
